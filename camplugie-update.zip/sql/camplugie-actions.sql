-- ============================================================================
-- Camplugie — notification buttons (Reply / Answer / Decline). Run ONCE in Supabase → SQL Editor.
-- Safe to run again.
-- ============================================================================
alter table public.device_tokens add column if not exists reply_token_hash text;
alter table public.device_tokens add column if not exists actions boolean not null default false;
alter table public.device_tokens add column if not exists app_version text;
create index if not exists device_tokens_reply_idx on public.device_tokens(reply_token_hash);
